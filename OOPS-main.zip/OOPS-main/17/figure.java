import Graphics.*;
import java.io.*;
class figure
	{
	public static void main(String []args) throws IOException
		{
		rectangle1 r = new rectangle1();
		r.getdata();
		r.area();
		student1 s= new student1();
		s.get();
		s.show();
		}
	}